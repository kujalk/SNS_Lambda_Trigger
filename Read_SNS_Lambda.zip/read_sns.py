import json

def read_message(event, context):
    try:
        message = event['Records'][0]['Sns']['Message']
        print(f"Message Received : {message}")

    except Exception as e:
        print(f"Error while reading message from SNS : {e}")
